#include "stdio.h"

int main {
    print "Helloooooooooo"
    print "Helloooooooooo 2"
}